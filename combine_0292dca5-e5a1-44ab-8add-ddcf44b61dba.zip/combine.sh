#!/usr/bin/env bash
# Reassemble buildings_damage.fgb from chunks.
# Run from this directory:
#   bash combine.sh
# Then move the result:
#   mv buildings_damage.fgb ../buildings_damage.fgb

cat buildings_damage.fgb.part* > buildings_damage.fgb
echo "Done: $(du -h buildings_damage.fgb | cut -f1)  buildings_damage.fgb"
