from flask import Flask, send_file, jsonify, Response, request
import csv, pathlib, json

app = Flask(__name__)
BASE_DIR = pathlib.Path(__file__).parent
DATA_DIR  = BASE_DIR / "data"


# ── Helpers ───────────────────────────────────────────────────────────────────
def _intv(s):
    try: return int(s.strip()) if s and s.strip() else None
    except: return None


# ── Pages ─────────────────────────────────────────────────────────────────────
@app.get("/")
@app.get("/sar")
def sar_index():
    resp = send_file(BASE_DIR / "index_sar.html")
    resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return resp


# ── Static data ───────────────────────────────────────────────────────────────
@app.get("/data/buildings.fgb")
def buildings_fgb():
    path = DATA_DIR / "buildings_damage.fgb"
    if not path.exists():
        return Response(status=404)
    file_size = path.stat().st_size
    range_header = request.headers.get("Range")
    if range_header:
        byte_range = range_header.replace("bytes=", "")
        start_str, end_str = byte_range.split("-")
        start = int(start_str)
        end = int(end_str) if end_str else file_size - 1
        with open(path, "rb") as f:
            f.seek(start)
            chunk = f.read(end - start + 1)
        resp = Response(chunk, status=206, mimetype="application/octet-stream")
        resp.headers["Content-Range"]  = f"bytes {start}-{end}/{file_size}"
        resp.headers["Content-Length"] = str(len(chunk))
        resp.headers["Accept-Ranges"]  = "bytes"
        return resp
    resp = send_file(str(path), mimetype="application/octet-stream")
    resp.headers["Accept-Ranges"]  = "bytes"
    resp.headers["Cache-Control"]  = "public, max-age=86400"
    return resp


@app.get("/api/meta")
def meta():
    path = DATA_DIR / "meta.json"
    if not path.exists():
        return jsonify({"error": "not found"}), 404
    resp = send_file(str(path), mimetype="application/json")
    resp.headers["Cache-Control"] = "public, max-age=3600"
    return resp


@app.get("/api/boundaries")
def boundaries():
    path = DATA_DIR / "kumamoto_admin.geojson"
    if not path.exists():
        return jsonify({"error": "not found"}), 404
    resp = send_file(str(path), mimetype="application/json")
    resp.headers["Cache-Control"] = "public, max-age=3600"
    return resp


@app.get("/api/eq-grid")
def eq_grid():
    path = DATA_DIR / "eq_grid.json"
    if not path.exists():
        return jsonify({"error": "not found"}), 404
    resp = send_file(str(path), mimetype="application/json")
    resp.headers["Cache-Control"] = "public, max-age=3600"
    return resp


@app.get("/api/eq-sites")
def eq_sites():
    try:
        sites = []
        with open(DATA_DIR / "eq_sites.csv", newline="", encoding="utf-8-sig") as f:
            for i, row in enumerate(csv.DictReader(f)):
                try:
                    lat = float(row["latitude"])
                    lon = float(row["longitude"])
                except (ValueError, KeyError):
                    continue
                sites.append({
                    "site_id":         i + 1,
                    "name":            row.get("location_name", ""),
                    "lat":             lat,
                    "lon":             lon,
                    "municipality":    row.get("municipality", ""),
                    "shindo":          row.get("jma_shindo", ""),
                    "damage_type":     row.get("damage_type", ""),
                    "damaged_element": row.get("damaged_element", ""),
                    "deaths":          _intv(row.get("deaths_at_site", "")),
                    "deaths_muni":     _intv(row.get("deaths_in_municipality", "")),
                    "status":          row.get("site_status", ""),
                    "status_as_of":    row.get("status_as_of", ""),
                    "radius":          _intv(row.get("estimated_radius_m", "")),
                    "source":          row.get("source", ""),
                    "url":             row.get("url", ""),
                    "url2":            row.get("url_secondary", ""),
                    "address":         row.get("registered_address", ""),
                    "notes":           row.get("notes", ""),
                })
        return Response(json.dumps(sites, separators=(",", ":")), mimetype="application/json")
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── SAM segments (persisted GeoJSON) ─────────────────────────────────────────
@app.get("/data/sam_segments.geojson")
def sam_segments():
    path = DATA_DIR / "sam_segments.geojson"
    if not path.exists():
        return jsonify({"error": "not found"}), 404
    resp = send_file(str(path), mimetype="application/json")
    resp.headers["Cache-Control"] = "no-cache"
    return resp


def _load_segments():
    path = DATA_DIR / "sam_segments.geojson"
    if not path.exists():
        return []
    return json.load(open(str(path))).get("features", [])


def _save_segments(feats):
    path = DATA_DIR / "sam_segments.geojson"
    for i, f in enumerate(feats):
        f["properties"]["id"] = i
    json.dump({"type": "FeatureCollection", "features": feats}, open(str(path), "w"))


@app.post("/api/sam_save")
def sam_save():
    try:
        new_features = request.json.get("features", [])
        existing = _load_segments()
        all_feats = existing + new_features
        _save_segments(all_feats)
        return jsonify({"saved": len(new_features), "total": len(all_feats)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.delete("/api/sam_segment/<int:seg_id>")
def sam_delete(seg_id):
    try:
        feats = [f for f in _load_segments() if f["properties"]["id"] != seg_id]
        _save_segments(feats)
        return jsonify({"deleted": seg_id, "total": len(feats)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.post("/api/sam_clear")
def sam_clear():
    try:
        _save_segments([])
        return jsonify({"total": 0})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    print("Kumamoto SAR  ->  http://localhost:5052")
    app.run(host="0.0.0.0", port=5052, debug=False)
