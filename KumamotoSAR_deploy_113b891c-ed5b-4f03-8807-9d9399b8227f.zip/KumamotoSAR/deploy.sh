#!/usr/bin/env bash
# deploy.sh
# One-command deploy of KumamotoSAR to a fresh AWS EC2 instance.
#
# Prerequisites:
#   - AWS CLI configured (aws configure)
#   - An existing EC2 key pair in your target region
#
# Usage:
#   KEY_NAME=my-key KEY_FILE=~/.ssh/my-key.pem ./deploy.sh
#
# Optional overrides (env vars):
#   REGION         default: ap-northeast-1  (Tokyo — closest to Kumamoto)
#   INSTANCE_TYPE  default: t3.small        (2 vCPU / 2 GB — enough for static serving)
#   PORT           default: 5052

set -euo pipefail

# ── Config ────────────────────────────────────────────────────────────────────
KEY_NAME="${KEY_NAME:?Set KEY_NAME to your EC2 key pair name}"
KEY_FILE="${KEY_FILE:?Set KEY_FILE to the path of your .pem file}"
REGION="${REGION:-ap-northeast-1}"
INSTANCE_TYPE="${INSTANCE_TYPE:-t3.small}"
PORT="${PORT:-5052}"
APP_NAME="kumamotosar"
APP_DIR="$(cd "$(dirname "$0")" && pwd)"   # folder this script lives in
REMOTE_DIR="/opt/$APP_NAME"
SSH_OPTS="-i $KEY_FILE -o StrictHostKeyChecking=no -o ConnectTimeout=5"

echo "=== KumamotoSAR Deploy ==="
echo "  Region        : $REGION"
echo "  Instance type : $INSTANCE_TYPE"
echo "  App dir       : $APP_DIR"
echo ""

# ── Resolve latest Ubuntu 22.04 LTS AMI ──────────────────────────────────────
echo "[1/6] Resolving Ubuntu 22.04 AMI..."
AMI_ID=$(aws ssm get-parameter \
  --name /aws/service/canonical/ubuntu/server/22.04/stable/current/amd64/hvm/ebs-gp2/ami-id \
  --region "$REGION" --query Parameter.Value --output text)
echo "  AMI: $AMI_ID"

# ── Create security group (idempotent) ────────────────────────────────────────
echo "[2/6] Configuring security group..."
SG_NAME="$APP_NAME-sg"
SG_ID=$(aws ec2 create-security-group \
  --group-name "$SG_NAME" \
  --description "KumamotoSAR: SSH + app port" \
  --region "$REGION" \
  --query GroupId --output text 2>/dev/null) || \
SG_ID=$(aws ec2 describe-security-groups \
  --group-names "$SG_NAME" --region "$REGION" \
  --query 'SecurityGroups[0].GroupId' --output text)

aws ec2 authorize-security-group-ingress \
  --group-id "$SG_ID" --protocol tcp --port 22 \
  --cidr 0.0.0.0/0 --region "$REGION" 2>/dev/null || true
aws ec2 authorize-security-group-ingress \
  --group-id "$SG_ID" --protocol tcp --port "$PORT" \
  --cidr 0.0.0.0/0 --region "$REGION" 2>/dev/null || true
echo "  Security group: $SG_ID  (ports 22, $PORT open)"

# ── Launch instance ───────────────────────────────────────────────────────────
echo "[3/6] Launching EC2 instance..."
INSTANCE_ID=$(aws ec2 run-instances \
  --image-id "$AMI_ID" \
  --instance-type "$INSTANCE_TYPE" \
  --key-name "$KEY_NAME" \
  --security-group-ids "$SG_ID" \
  --block-device-mappings '[{"DeviceName":"/dev/sda1","Ebs":{"VolumeSize":10,"VolumeType":"gp3"}}]' \
  --user-data '#!/bin/bash
apt-get update -y
apt-get install -y python3-pip
pip3 install flask gunicorn' \
  --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=$APP_NAME}]" \
  --region "$REGION" \
  --query 'Instances[0].InstanceId' --output text)
echo "  Instance ID: $INSTANCE_ID"

echo "  Waiting for instance to reach running state..."
aws ec2 wait instance-running --instance-ids "$INSTANCE_ID" --region "$REGION"

PUBLIC_IP=$(aws ec2 describe-instances \
  --instance-ids "$INSTANCE_ID" --region "$REGION" \
  --query 'Reservations[0].Instances[0].PublicIpAddress' --output text)
echo "  Public IP: $PUBLIC_IP"

# ── Wait for SSH ──────────────────────────────────────────────────────────────
echo "[4/6] Waiting for SSH to become available..."
for i in $(seq 1 36); do
  ssh $SSH_OPTS ubuntu@$PUBLIC_IP true 2>/dev/null && break
  printf "  attempt %d/36...\r" "$i"
  sleep 10
done
echo ""

# ── Upload app ────────────────────────────────────────────────────────────────
echo "[5/6] Uploading app files (includes 470MB FGB — takes a few minutes)..."
rsync -az --info=progress2 \
  --exclude '__pycache__' \
  --exclude '*.pyc' \
  --exclude 'backup_*' \
  -e "ssh $SSH_OPTS" \
  "$APP_DIR/" ubuntu@$PUBLIC_IP:$REMOTE_DIR/

# ── Install deps + register systemd service ───────────────────────────────────
echo "[6/6] Installing requirements and starting service..."
ssh $SSH_OPTS ubuntu@$PUBLIC_IP bash << REMOTE
set -e
cd $REMOTE_DIR
pip3 install -r requirements.txt -q

# Wait for user-data gunicorn install if still running
for i in \$(seq 1 12); do command -v gunicorn &>/dev/null && break; sleep 5; done

sudo tee /etc/systemd/system/$APP_NAME.service > /dev/null << SVC
[Unit]
Description=Kumamoto SAR App
After=network.target

[Service]
User=ubuntu
WorkingDirectory=$REMOTE_DIR
ExecStart=/usr/local/bin/gunicorn -w 2 -b 0.0.0.0:$PORT --timeout 120 app:app
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SVC

sudo systemctl daemon-reload
sudo systemctl enable $APP_NAME
sudo systemctl start $APP_NAME
sudo systemctl status $APP_NAME --no-pager
REMOTE

echo ""
echo "================================================"
echo "  App live:  http://$PUBLIC_IP:$PORT"
echo "  SSH:       ssh -i $KEY_FILE ubuntu@$PUBLIC_IP"
echo "  Logs:      sudo journalctl -u $APP_NAME -f"
echo "  Stop:      sudo systemctl stop $APP_NAME"
echo "================================================"
