from flask import Flask

flaskapp = Flask(__name__)

@flaskapp.route("/")
def hello():
    return "------|||||||-------"

if __name__ == "__main__":
    flaskapp.run(debug=True)
