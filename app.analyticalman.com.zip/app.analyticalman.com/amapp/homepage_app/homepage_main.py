from flask import Flask
from salary_pred_app import salary_app
from .home_design import home_app

hp_app = Flask(__name__)

# Load Dash app at the root endpoint
dash_app = home_app(hp_app, "/")

# Load Dash app at the root endpoint
dash_app2 = salary_app(hp_app, "/salary/")


if __name__ == '__main__':
    hp_app.run(debug=True)
