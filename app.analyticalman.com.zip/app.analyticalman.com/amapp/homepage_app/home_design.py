import dash
from dash import dcc, html
import dash_bootstrap_components as dbc

def home_app(flask_app, url_base_pathname):
    external_stylesheets = [dbc.themes.BOOTSTRAP, "/assets/styles.css"]

    dash_app = dash.Dash(
        __name__,
        server=flask_app,
        url_base_pathname=url_base_pathname,
        external_stylesheets=external_stylesheets
    )

    header = dbc.CardHeader(
        dbc.NavbarSimple(
            children=[
                dbc.NavItem(dbc.NavLink("Home", href="https://app.analyticalman.com",  style={"font-family": "Comfortaa", "font-size" :"13px",},)),
                dbc.NavItem(dbc.NavLink("Blog", href="https://analyticalman.com",  style={"font-family": "Comfortaa", "font-size" :"13px",},)),
                dbc.NavItem(dbc.NavLink("About", href="https://analyticalman.com/?page_id=14",  style={"font-family": "Comfortaa", "font-size" :"13px",},)),
                dbc.NavItem(dbc.NavLink("Contact", href="https://analyticalman.com/?page_id=16",  style={"font-family": "Comfortaa", "font-size" :"13px",},)),
                
            ],
            brand="ANALYTICAL MAN | APPS",
            brand_href=url_base_pathname,
            className="navbar navbar-expand-lg navbar-light bg-light",
            color="light",
            style={
                "background-image": "url('/assets/img/header_bg2B.png')", 
                "background-size": "cover",
                "background-position": "center center",  
                "height": "auto",  
                "width": "auto",
            },
            ),
    ) 
    footer = dbc.CardFooter(
        dbc.Row(
            dbc.Col(
                html.P("Copyright © 2023. All rights reserved"),
                style={'text-align': 'center',"font-family": "Comfortaa", "font-size" :"13px", "color": "gray",'padding-top': '3px'}
            ), 
        ),
        style={"background-image": "url('/assets/img/footer_bg2.png')", 
                   "background-size": "cover",
                   "background-position": "center center",
                   "height": "25px",
                   "width": "auto",
                   },
    )

    cat_label = dbc.CardFooter(
        dbc.Row(
            dbc.Col(
                html.H6("APP CATEGORIES"),
                style={'text-align': 'center',"font-family": "Comfortaa", "font-size" :"11px", "color": "black",'padding-top': '6px'}
            ), 
        ),
        style={"background-image": "url('/assets/img/header_bg.png')", 
                   "background-size": "cover",
                   "background-position": "center center",
                   #"height": "30px",
                   #"width": "auto",
                   },
    )

    devider = dbc.CardFooter(
        style={"background-image": "url('/assets/img/header_bg.png')", 
                   "background-size": "cover",
                   "background-position": "center center",
                   "height": "3px",
                   "width": "auto","margin-top": "3px","margin-bottom": "6px",
                   },
    )

    devider2 = dbc.CardFooter(
        style={"background-image": "url('/assets/img/footer_bg.png')", 
                   "background-size": "cover",
                   "background-position": "center center",
                   "height": "3px",
                   "width": "auto","margin-top": "3px","margin-bottom": "3px",
                   },
    )
    middle_section = dbc.Container(
        [
        dbc.Row(
            [
                dbc.Col(html.Img(src=url_base_pathname + "assets/img/mid-img.png", style={"width":"150px"}), width=5),
                dbc.Col(
                    [
                        html.Div("Check out our Data-analytics and Machine Learning based web applications. We appreciate your feedback. Your requests and ideas will be prioritized for future apps and blog posts.", 
                                 style={
                                    "display": "flex",
                                    "flex-direction": "column",
                                    "justify-content": "center",
                                    "align-items": "center",
                                    #"height": "200px",
                                    "font-family": "Comfortaa", "font-size" :"13px",
                                },
                                 
                                 ),
                    ],
                    width=7,
                ),
            ],
            style={"margin-top": "8px","margin-bottom": "8px"},
        )],
    )

    button_section = dbc.Container([

        dbc.Row([
            dbc.Col([ 
                html.Div([
                    html.P("Feel free to use the available apps (green ones)"),
                    ],style={"margin": "2px auto", "text-align": "center", "font-family": "Comfortaa", "font-size" :"13px"},
                        )
                    ],),
                ],),
        devider2,
        dbc.Row([
            dbc.Col([ 
                html.Div([
                    html.H5("FINANCE", style={"margin": "3px auto", "text-align": "center", "font-family": "Atma", "font-size" :"23px"},),
                    devider2,
                    dbc.Row([
                            dbc.Col(dbc.Button("SWE Salary Prediction", href="https://app.analyticalman.com/salary/", className="custom-button", size="sm", style={"margin": "5px","font-size" :"13px"},), width=6,  align="center" ),
                            dbc.Col(dbc.Button("Laptop Price Prediction", href="https://analyticalman.com/", className="custom-button-down", size="sm", style={"margin": "5px","font-size" :"13px"},), width=6, align="center"),
                            #dbc.Col(dbc.Button("Phone Price Prediction", href="https://analyticalman.com/", className="custom-button-down", size="sm", style={"margin": "5px","font-size" :"13px"},), width=4, align="center"),
                            ],justify="center", style={"margin": "5px auto", "text-align": "center", "font-family": "Comfortaa", "font-size" :"10px"},
                            ),],
                        )
                    ],),
                ],),
        devider2,

        dbc.Row([
            dbc.Col([ 
                html.Div([
                    html.H5("MEDICAL", style={"margin": "3px auto", "text-align": "center", "font-family": "Atma", "font-size" :"23px"},),
                    devider2,
                    dbc.Row([
                            dbc.Col(dbc.Button("Diabetes Prediction", href="https://analyticalman.com/", className="custom-button-down", size="sm", style={"margin": "5px","font-size" :"13px"},), width=6, align="center"),
                            dbc.Col(dbc.Button("Disease Classification", href="https://analyticalman.com/", className="custom-button-down", size="sm", style={"margin": "5px","font-size" :"13px"},), width=6, align="center"),
                            #dbc.Col(dbc.Button("Covid Case Analysis", href="https://analyticalman.com/", className="custom-button-down", size="sm", style={"margin": "5px","font-size" :"13px"},), width=4, align="center"),
                            ],justify="center", style={"margin": "5px auto", "text-align": "center", "font-family": "Comfortaa", "font-size" :"10px"},
                            ),],
                        )
                    ],),
                ],),
        devider2,
        dbc.Row([
            dbc.Col([ 
                html.Div([
                    html.H5("ENVIRONMENT", style={"margin": "3px auto", "text-align": "center", "font-family": "Atma", "font-size" :"23px"},),
                    devider2,
                    dbc.Row([
                            dbc.Col(dbc.Button("Solar Energy Prediction", href="https://analyticalman.com/", className="custom-button-down", size="sm", style={"margin": "5px", "font-size" :"13px"},), width=6, align="center"),
                            #dbc.Col(dbc.Button("Satellite Image Analysis", href="https://analyticalman.com/", className="custom-button-down", size="sm", style={"margin": "5px", "font-size" :"13px"},), width=4, align="center"),
                            dbc.Col(dbc.Button("Weather Forecasting", href="https://analyticalman.com/", className="custom-button-down", size="sm", style={"margin": "5px", "font-size" :"13px"},), width=6, align="center"),
                            ],justify="center", style={"margin": "5px auto", "text-align": "center", "font-family": "Comfortaa", "font-size" :"10px"},
                            ),],
                        )
                    ],),
                ],),
        devider2,
            ],)

    # dash_app.layout = html.Div([
    #     dcc.Location(id="url", refresh=False),
    #     header,
    #     devider,
    #     middle_section,
    #     devider,
    #     cat_label,
    #     devider,
    #     button_section,
    #     footer,
    # ])

    dash_app.layout = dbc.Container([
        header,
        devider,
        middle_section,
        devider,
        cat_label,
        devider,
        button_section,
        footer,
    ])
    return dash_app
