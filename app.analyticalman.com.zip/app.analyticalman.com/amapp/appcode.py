from homepage_app import hp_app

if __name__ == "__main__":
    hp_app.run(debug=True)