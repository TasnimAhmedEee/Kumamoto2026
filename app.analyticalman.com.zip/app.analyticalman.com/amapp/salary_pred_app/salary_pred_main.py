import dash
import dash_bootstrap_components as dbc
from dash import dcc, html, Input, Output, State
from dash.exceptions import PreventUpdate
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import tflite_runtime.interpreter as tflite
#from keras import models
#import tensorflow as tf
import string
#import keras

def salary_app(flask_app, url_base_pathname):
    external_stylesheets = [dbc.themes.BOOTSTRAP, "/assets/styles.css"]

    dash_app = dash.Dash(
        __name__,
        server=flask_app,
        url_base_pathname=url_base_pathname,
        external_stylesheets=external_stylesheets
    )

    header = dbc.CardHeader(
        dbc.NavbarSimple(
            children=[
                dbc.NavItem(dbc.NavLink("Home", href="https://app.analyticalman.com",  style={"font-family": "Comfortaa", "font-size" :"13px",},)),
                dbc.NavItem(dbc.NavLink("Blog", href="https://analyticalman.com",  style={"font-family": "Comfortaa", "font-size" :"13px",},)),
                dbc.NavItem(dbc.NavLink("About", href="https://analyticalman.com/?page_id=14",  style={"font-family": "Comfortaa", "font-size" :"13px",},)),
                dbc.NavItem(dbc.NavLink("Contact", href="https://analyticalman.com/?page_id=16",  style={"font-family": "Comfortaa", "font-size" :"13px",},)),
                
            ],
            brand="ANALYTICAL MAN | APPS",
            brand_href=url_base_pathname,
            className="navbar navbar-expand-lg navbar-light bg-light",
            color="light",
            style={
                "background-image": "url('/assets/img/header_bg2B.png')", 
                "background-size": "cover",
                "background-position": "center center",  
                "height": "auto",  
                "width": "auto",
            },
            ),
    ) 
    footer = dbc.CardFooter(
        dbc.Row(
            dbc.Col(
                html.P("Copyright © 2023. All rights reserved"),
                style={'text-align': 'center',"font-family": "Comfortaa", "font-size" :"13px", "color": "gray",'padding-top': '3px'}
            ), 
        ),
        style={"background-image": "url('/assets/img/footer_bg2.png')", 
                   "background-size": "cover",
                   "background-position": "center center",
                   "height": "25px",
                   "width": "auto",
                   },
    )

    # Load the TFLite model
    interpreter = tflite.Interpreter(model_path='/amapp/salary_pred_app/data/salary_dnn.tflite')
    interpreter.allocate_tensors()

    # Get input and output details
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()

    # Load CSV data into a Pandas DataFrame
    data = pd.read_csv('/amapp/salary_pred_app/data/salary_data_.csv')
    country_mapping = data[['COUNTRY','COUNTRY CODE']].copy().set_index('COUNTRY')['COUNTRY CODE'].to_dict()
    # print(country_mapping, flush=True)

    #category mapping
    cat_mapping = {
        'SITE RELIABILITY ENGINEER':'DEVOPS ROLES','SYSTEM ADMINISTRATOR' : 'DEVOPS ROLES','DATABASE ADMINISTRATOR': 'DEVOPS ROLES',
        'SECURITY PROFESSIONAL': 'DEVOPS ROLES','DEVOPS SPECIALIST' :'DEVOPS ROLES','CLOUD INFRASTRUCTURE ENGINEER': 'DEVOPS ROLES',
        'MACHINE LEARNING ENGINEER' : 'AI ML DS ROLES','DATA SCIENTIST': 'AI ML DS ROLES','DATA ENGINEER' : 'AI ML DS ROLES',
        'DATA ARCHITECT' : 'AI ML DS ROLES','DATA SCIENCE OR ML SPECIALIST' : 'AI ML DS ROLES','DATA ANALYST' : 'AI ML DS ROLES',
        'BUSINESS INTELLIGENCE ENGINEER' : 'AI ML DS ROLES','PROJECT MANAGER': 'MANAGERS','PRODUCT MANAGER': 'MANAGERS',
        'DATA SCIENCE MANAGER': 'MANAGERS', 'DATA MANAGER': 'MANAGERS','DATA ANALYTICS MANAGER' : 'MANAGERS',
        'ENGINEERING MANAGER': 'MANAGERS','FULLSTACK DEVELOPER' : 'DEVELOPERS','BACKEND DEVELOPER': 'DEVELOPERS',
        'FRONTEND DEVELOPER': 'DEVELOPERS','DESKTOP APP DEVELOPER': 'DEVELOPERS','MOBILE APP DEVELOPER': 'DEVELOPERS',
        'EMBEDDED SYSTEMS DEVELOPER': 'DEVELOPERS','DEVELOPER QA OR TEST': 'DEVELOPERS','GAME OR GRAPHICS DEVELOPER': 'DEVELOPERS',
    }
    # Define your custom mappings
    education_mapping = {'UNDERGRAD': 0, 'BACHELOR': 1, 'MASTER': 2, 'DOCTORAL': 3}
    company_size_mapping = {'SMALL': 0, 'MEDIUM': 1, 'LARGE': 2}
    exp_level_mapping = {'EN': 0, 'MI': 1, 'SE': 2, 'EX': 3}
    age_mapping = {'-18':0, '18-24':1, '25-34':2, '35-44':3, '45-54':4, '55+':5}

    ref_columns = [
        'EXP LEVEL', 'COMPANY SIZE', 'WORK EXP', 'AGE', 'EDUCATION', 'AR', 'AT','AU', 'BE', 'BG', 'BR', 'CA', 'CH', 'CL', 'CN', 'CO', 'CZ', 'DE', 'DK',
        'EE', 'ES', 'FI', 'FR', 'GB', 'GR', 'HR', 'HU', 'IE', 'IL', 'IN', 'IR','IT', 'JP', 'KR', 'LT', 'MX', 'NL', 'NO', 'NZ', 'PL', 'PT', 'RO', 'RS',
        'RU', 'SE', 'SG', 'SI', 'TR', 'UA', 'US', 'ZA', 'AI ML DS ROLES','DEVELOPERS', 'DEVOPS ROLES', 'MANAGERS', 'BACKEND DEVELOPER',
        'BUSINESS INTELLIGENCE ENGINEER', 'CLOUD INFRASTRUCTURE ENGINEER','DATA ANALYST', 'DATA ARCHITECT', 'DATA ENGINEER', 'DATA MANAGER',
        'DATA SCIENCE OR ML SPECIALIST', 'DATA SCIENTIST','DESKTOP APP DEVELOPER', 'DEVELOPER QA OR TEST', 'DEVOPS SPECIALIST',
        'EMBEDDED SYSTEMS DEVELOPER', 'ENGINEERING MANAGER','FRONTEND DEVELOPER', 'FULLSTACK DEVELOPER',
        'GAME OR GRAPHICS DEVELOPER', 'MACHINE LEARNING ENGINEER','MOBILE APP DEVELOPER', 'SECURITY PROFESSIONAL',
        'SITE RELIABILITY ENGINEER', 'SYSTEM ADMINISTRATOR']

    #get necessary columns for the UI input
    input_columns = ['COUNTRY','JOB TITLE (BY COUNTRY)', 'COMPANY SIZE', 'EDUCATION (DEGREE)', 'AGE (YEARS)','EXPERIENCE (YEARS)']
    df = data[input_columns]

    
    init_data = {}
    init_data["COUNTRY"] = "UNITED STATES"
    init_data["JOB TITLE (BY COUNTRY)"] = "BACKEND DEVELOPER"
    init_data["COMPANY SIZE"] = "MEDIUM"
    init_data["EDUCATION (DEGREE)"] = "BACHELOR"
    init_data["AGE (YEARS)"] = "25-34"
    init_data["EXPERIENCE (YEARS)"] = 5
    
    
    # Create a dictionary to store options for each column
    column_options = {}
    for col in input_columns: 
        #options = [{'label': value, 'value': value} for value in df[col].unique()]
        options = [{'label': value.title() if isinstance(value, str) else value, 'value': value} for value in df[col].unique()]
        if(col=="COMPANY SIZE"):
            #changable lables in job title
            exception_dict={'Medium':'Medium (100-5K People)','Small':'Small (0-99 People)', 'Large':'Large (5K+ People)'}
            #print(options, flush=True)
            for option in options:
                label = option['label']
                if label in exception_dict:
                    option['label'] = exception_dict[label]
        
        column_options[col] = options
    # print(column_options, flush=True)
    # Get the min and max values for the "WORK EXP" column
    min_work_exp = df['EXPERIENCE (YEARS)'].min()
    max_work_exp = df['EXPERIENCE (YEARS)'].max()


    # Create input selectors for each column with dcc.Dropdown
    input_fields = dbc.Container([
        dbc.Row([
            dbc.Col(html.Div(html.Label(col.title(),style={"font-family": "Comfortaa", "font-size" :"13px"} )), style={'background-color': 'lightblue', # Display the column name with a background color
                                                      'border': '1px solid gray', 'border-radius': '5px'}, width=4),  
            dbc.Col(
                dcc.Dropdown(id=f'{col.lower()}-input', options=column_options[col], # value=column_options[col][0]['value'], 
                             value=init_data[col],style={"font-family": "Comfortaa", "font-size" :"13px"},
                             clearable=False,searchable=False) if col != 'EXPERIENCE (YEARS)' else
                dbc.Row([
                    dbc.Col(dcc.Slider(id='work-exp-input', min=int(min_work_exp), max=int(max_work_exp), step=1, value=init_data[col],#5,
                                       marks={int(min_work_exp): str(int(min_work_exp)), int(max_work_exp): str(int(max_work_exp))}, 
                                       tooltip={"placement": "bottom", "always_visible": True}, ), width=12),
                ], style={'align-items': 'center','margin': '3px','background-color': 'lightgray',
                          'border': '3px solid lightgray', 'border-radius': '5px'
                          }
                ),
                width=8,
            )
        ], style={'margin-top': '1px', 'margin-bottom': '1px',})
        for col in input_columns 
    ])
         
    control_buttons =  dbc.Container([
        dbc.Row([dbc.Col(dbc.Button("Get Prediction", id="get-analytics-button", color="primary", disabled=True),
                         style={"font-family": "Comfortaa", "font-size" :"13px"}, width=6),
                 dbc.Col(dbc.Button("Reset Input", id="reset-button", color="primary", disabled=True),
                         style={"font-family": "Comfortaa", "font-size" :"13px"} ,width=6),
                ], className="controlller-button",style={'margin-top': '5px', 'margin-bottom': '1px',},
                ),],fluid=True,style={'margin-top': '1px', 'margin-bottom': '1px',},
                )
    
    output_fields =  dbc.Container([
        dbc.Row([dbc.Col(html.Div(html.Label("Status")), 
                         style={"font-family": "Comfortaa", "font-size" :"13px",'background-color': 'lightblue', 
                                'border': '1px solid gray', 'border-radius': '5px'}, width=3),
                 dbc.Col(html.Div("Input Activated",id="analytics-output", 
                                  style={"font-family": "Comfortaa", "font-size" :"13px","border": "1px solid gray",
                                         "border-radius": "5px","text-align":"center"}), width=9),
                ], style={'margin-top': '5px', 'margin-bottom': '3px',},
                ),],fluid=True, style={'margin-top': '1px', 'margin-bottom': '1px',},
                )
    Prediction_field =  dbc.Container([
        dbc.Row([dbc.Col(html.Div("",id="prediction-output-", 
                                  style={"border": "1px solid gray","border-radius": "5px",
                                         "font-family": "Comfortaa", "font-size" :"13px",
                                         "text-align":"center","display": "none",
                                         }), width=12),
                ],style={'margin-top': '5px', 'margin-bottom': '3px',},
                ),],fluid=True, style={'margin-top': '1px', 'margin-bottom': '1px',},
                )
    #----------------------------------------------------------------------------------------------------
    app_detail =  dbc.Container([
        dbc.Row([dbc.Col(html.P("Predict Salary with Machine Learning (ML) and Visualize Survey Data", id="app-detail", 
                                  style={"text-align":"center", "font-family": "Comfortaa", "font-size" :"13px",
                                         }), width=12),
                ], style={'margin-top': '2px', 'margin-bottom': '2px',},
                ),],fluid=True, style={'margin-top': '1px', 'margin-bottom': '1px',},
                )
    footer_detail =  dbc.Container([
        dbc.Row([dbc.Col(html.P(["Data for this Salary Prediction App is collected from ",
                                 dcc.Link("Stack Overflow Developer Survey",
                                            href="https://survey.stackoverflow.co/2023/",
                                            target="_blank",  # Opens the link in a new tab
                                            style={'textDecoration': 'none'},
                                        )," and ",
                                dcc.Link("ai-jobs.net",
                                            href="https://ai-jobs.net/salaries/download/",
                                            target="_blank",  # Opens the link in a new tab
                                            style={'textDecoration': 'none'},
                                        )," for the year 2022 and 2023 ",
                                        ], id="footer-detail", 
                                  style={"text-align":"center", "font-family": "Comfortaa", "font-size" :"13px",
                                         }), width=12),
                ], style={'margin-top': '2px', 'margin-bottom': '2px',},
                ),],fluid=True, style={'margin-top': '1px', 'margin-bottom': '1px',},
                )
    input_detail =  dbc.Container([
        dbc.Row([dbc.Col(html.P("Select Input and Get Salary Prediction from Deep Neural Network (DNN) based ML Model", id="salary-input-detail-", 
                                  style={"text-align":"center", "font-family": "Comfortaa", "font-size" :"13px",
                                         }), width=12),
                ], style={'margin-top': '2px', 'margin-bottom': '2px',},
                ),],fluid=True, style={'margin-top': '1px', 'margin-bottom': '1px',},
                )
    get_input_header =  dbc.Container([
        dbc.Row([dbc.Col(html.Div("INPUT SELECTION", id="get-input-header", 
                                  style={# "border": "1px solid gray","border-radius": "5px",
                                        "background-image": "url('/assets/img/divbg2.png')", 
                                        "background-size": "cover",
                                        "background-position": "center center",
                                         "text-align":"center", "font-family": "Comfortaa", "font-size" :"13px",
                                         'padding-top': '3px', 'padding-bottom': '3px',
                                         }), width=12),
                ], style={'margin-top': '2px', 'margin-bottom': '2px',},
                ),],fluid=True, style={'margin-top': '1px', 'margin-bottom': '8px',},
                )
    fig_title =  dbc.Container([
        dbc.Row([dbc.Col(html.Div("SALARY ANALYSIS", id="get-fig-title", 
                                  style={# "border": "1px solid gray","border-radius": "5px",
                                        "background-image": "url('/assets/img/divbg2.png')", 
                                        "background-size": "cover",
                                        "background-position": "center center",
                                         "text-align":"center", "font-family": "Comfortaa", "font-size" :"13px",
                                         'padding-top': '3px', 'padding-bottom': '3px',
                                         }), width=12),
                ], style={'margin-top': '2px', 'margin-bottom': '2px',},
                ),],fluid=True, style={'margin-top': '1px', 'margin-bottom': '8px',},
                )
    fig_header =  dbc.Container([
        dbc.Row([dbc.Col(html.P("Salary Analysis", id="analysis-header", 
                                  style={# "border": "1px solid gray","border-radius": "5px",
                                         "text-align":"center", "font-family": "Comfortaa", "font-size" :"13px",
                                        #  "background-image": "url('/assets/img/footer_bg2.png')", 
                                        #  "background-size": "cover",
                                        #  "background-position": "center center",
                                         }), width=12),
                ], style={'margin-top': '2px', 'margin-bottom': '2px',},
                ),],fluid=True, style={'margin-top': '1px', 'margin-bottom': '1px',},
                )
    app_header =  dbc.Container([
        dbc.Row([dbc.Col(html.Div("SOFTWARE ENGINEER SALARY PREDICTION", id="app-header", 
                                  style={# "border": "1px solid gray","border-radius": "5px",
                                         # 'background-color': 'orange',
                                        "background-image": "url('/assets/img/header_bg3B.png')", 
                                        "background-size": "cover",
                                        "background-position": "center center",
                                        "font-family": "Comfortaa", "font-size" :"13px",
                                        "text-align":"center",'padding-top': '5px', 'padding-bottom': '5px',"color": "black",
                                         }), width=12),
                ], style={'margin-top': '5px', 'margin-bottom': '3px',},
                ),],fluid=True, style={'margin-top': '1px', 'margin-bottom': '1px',},
                )
    
    devider_hidden =  dbc.Container([
        dbc.Row([dbc.Col(html.Div("", #id="divider", 
                                  style={#"border": "1px solid gray","border-radius": "5px",
                                         "text-align":"center",
                                         }), width=12),
                ], style={'margin-top': '10px', 'margin-bottom': '3px',},
                ),],fluid=True, style={'margin-top': '25px', 'margin-bottom': '1px',},
                )
    
    devider_top =  dbc.Container([
        dbc.Row([dbc.Col(html.Div("", #id="divider", 
                                  style={"border": "1px solid gray","border-radius": "5px",
                                         "text-align":"center",
                                         }), width=12),
                ], style={'margin-top': '5px', 'margin-bottom': '3px',},
                ),],fluid=True, style={'margin-top': '25px', 'margin-bottom': '1px',},
                )
    devider_bottom =  dbc.Container([
        dbc.Row([dbc.Col(html.Div("", #id="divider", 
                                  style={"border": "1px solid gray","border-radius": "5px",
                                         "text-align":"center",
                                         }), width=12),
                ], style={'margin-top': '5px', 'margin-bottom': '3px',},
                ),],fluid=True, style={'margin-top': '1px', 'margin-bottom': '10px',},
                )
    devider_photo = dbc.CardFooter(
        style={"background-image": "url('/assets/img/header_bg.png')", 
                   "background-size": "cover",
                   "background-position": "center center",
                   "height": "3px",
                   "width": "auto","margin-top": "3px","margin-bottom": "6px",
                   },
    )
    plotter = dbc.Container(
    [
        dbc.Row(
            [
                dbc.Col(
                    [
                        dbc.Row(
                            [
                                dbc.Col(
                                        html.Label("Median Salary by "),
                                        style={"font-family": "Comfortaa", "font-size" :"13px",
                                               'background-color': 'lightblue', 'border': '1px solid gray', 
                                               'border-radius': '5px'}, width=4,
                                    
                                ),
                                dbc.Col(
                                        dcc.Dropdown(
                                            id='filter-selector',
                                            options=[
                                                {'label': 'Education (Degree)', 'value': 'EDUCATION (DEGREE)'},
                                                {'label': 'Experience (Level)', 'value': 'EXPERIENCE (LEVEL)'},
                                                {'label': 'Remote Work Type', 'value': 'REMOTE WORK'},
                                                {'label': 'Age Groups', 'value': 'AGE (YEARS)'},
                                            ],
                                            value='EDUCATION (DEGREE)',clearable=False,searchable=False),
                                        style={"font-family": "Comfortaa", "font-size" :"13px",
                                               }, width=8,
                                    
                                ),
                            ],
                        ),
                        dbc.Row(
                            [
                                dbc.Col(
                                    dcc.Graph(id='median-salary-plot',
                                              config={  'staticPlot': True,
                                                        'displayModeBar': False,
                                                        'displaylogo': False,
                                                    },
                                              
                                                    ),style={"font-family": "Comfortaa", "font-size" :"13px",},
                                ),
                            ],
                        ),
                    ],
                    sm={'size': 12, 'order': 1},
                    md={'size': 12, 'order': 1},
                    lg={'size': 6, 'order': 1},
                    xl={'size': 6, 'order': 1},
                ),
                dbc.Col(
                    [
                        dbc.Row(
                            [
                                dbc.Col(
                                        html.Label("Salary Distribution For "),
                                        style={"font-family": "Comfortaa", "font-size" :"13px",
                                               'background-color': 'lightblue', 'border': '1px solid gray', 
                                               'border-radius': '5px'}, width=4,
                                ),
                                dbc.Col(
                                        dcc.Dropdown( id='value-selector',clearable=False,searchable=False),
                                        style={"font-family": "Comfortaa", "font-size" :"13px",}, width=8,
                                ),
                            ],
                        ),
                        dbc.Row(
                            [
                                dbc.Col(
                                    dcc.Graph(id='salary-distribution-histogram', 
                                              config={  'staticPlot': True,
                                                        'displayModeBar': False,
                                                        'displaylogo': False,
                                                    },
                                              
                                              ),style={"font-family": "Comfortaa", "font-size" :"13px",},
                                ),
                            ],
                        ),
                    ],
                    sm={'size': 12, 'order': 2},
                    md={'size': 12, 'order': 2},
                    lg={'size': 6, 'order': 2},
                    xl={'size': 6, 'order': 2},
                ),
            ],
        ),
    ],
    fluid=True,
)


    #-------------------------------------------------------------------------------------------------------

    
    #--------------------------------------------------------------------------------------------

    dash_app.layout = dbc.Container([
        header,
        app_header,
        app_detail,
        #devider_top,
        get_input_header,
        input_detail,
        #devider_bottom,
        input_fields,  # Use the * operator to unpack the list of input_fields
        control_buttons,
        output_fields,
        Prediction_field,
        #devider_top,
        devider_hidden,
        fig_title,
        fig_header,
        #devider_bottom,
        plotter,
        devider_hidden,
        footer_detail,
        footer
    ])
    #--------------------------------------------------------------------------------
    # Change the page title
    dash_app.title = "SWE Salary APP"

    @dash_app.callback(
        [
            Output("prediction-output-", "children"),
            Output("prediction-output-", "style"),
        ],
        [
            Input("analytics-output", "children"),
            Input("country-input", "value"),
            Input("job title (by country)-input", "value"),
            Input("age (years)-input", "value"),
            Input("company size-input", "value"),
            Input("education (degree)-input", "value"),
            Input("work-exp-input", "value"),
        ]
    )
    def prediction_function(analytics_output, country, job_title, age, company_size, education, work_exp):
        # Get the input that triggered the callback
        ctx = dash.callback_context
        trigger_id = ctx.triggered[0]["prop_id"] if ctx.triggered else None

        input_data = {}  # Create an empty dictionary to store input data

        if trigger_id == "analytics-output.children" and analytics_output == "Input Deactivated":
            # Collect the current values of all other inputs and store in the dictionary
            input_data["COUNTRY"] = country
            input_data["JOB TITLE"] = job_title
            input_data["AGE"] = age
            input_data["COMPANY SIZE"] = company_size
            input_data["EDUCATION"] = education
            input_data["WORK EXP"] = work_exp
            # Convert the dictionary to a DataFrame
            df = pd.DataFrame([input_data])
            # print("-----------------------------------------------",flush=True)
            # print(df,flush=True)


            # Function to convert years of experience to experience level
            def convert_to_experience_level(work_exp, mexp):
                experience_ranges = {
                    'EN': (0, 3),   # Entry-level / Junior
                    'MI': (3, 8),   # Mid-level / Intermediate
                    'SE': (8, 15),  # Senior-level / Expert
                    'EX': (15, mexp)  # Executive-level / Director
                }

                for level, (lower, upper) in experience_ranges.items():
                    if lower <= work_exp < upper:
                        return level
                return 'MI'
            
            # Apply the function to create a new column 'experience_level'
            df['EXP LEVEL'] = df['WORK EXP'].apply(convert_to_experience_level, mexp=max_work_exp)

            # Apply custom mappings to respective columns
            df['EDUCATION'] = df['EDUCATION'].replace(education_mapping)
            df['COMPANY SIZE'] = df['COMPANY SIZE'].replace(company_size_mapping)
            df['EXP LEVEL'] = df['EXP LEVEL'].replace(exp_level_mapping)
            df['AGE'] = df['AGE'].replace(age_mapping)
            df['JOB CATEGORY'] = df['JOB TITLE'].replace(cat_mapping)
            df['COUNTRY CODE'] = df['COUNTRY'].replace(country_mapping)
            df = df.drop('COUNTRY', axis=1)
            # print("-----------------------------------------------",flush=True)
            # print(df.iloc[0].to_dict(),flush=True)
            # print("-----------------------------------------------",flush=True)
            # Apply one-hot encoding to the dataset.
            datin = pd.get_dummies(df, columns=['COUNTRY CODE', 'JOB CATEGORY', 'JOB TITLE'], prefix='', prefix_sep='').replace({True: 1})
            # print(datin.iloc[0].to_dict(),flush=True)
            # print("-----------------------------------------------",flush=True)
            # Loop through the columns in the list
            for col in ref_columns:
                # Check if the column exists in the DataFrame
                if col not in datin.columns:
                    # If it doesn't exist, create a new column with zeros
                    datin[col] = 0
            # print("-----------------------------------------------",flush=True)
            # print(datin.iloc[0].to_dict(), flush=True)

            # Reindex the DataFrame with the desired column order
            datin = datin.reindex(columns=ref_columns)
            # print("-----------------------------------------------",flush=True)
            # print(datin.iloc[0].to_dict(), flush=True)

            #print(datin.columns, flush=True)
            #print(np.asarray(datin).shape, flush=True)
            # Load the saved model
            #-----------------------------------VVVI-------------------------------------------
            #loaded_model = tf.keras.models.load_model('/amapp/salary_pred_app/data/salary_dnn.h5')
            #test_predictions = loaded_model.predict(np.asarray(datin)).flatten()
            #------------------------------------------------------------------------------
            # print(test_predictions[0], flush=True)
            #print(input_data, flush=True)
            #--------------------------------------------------------------------------------
            # Set input tensor
            interpreter.set_tensor(input_details[0]['index'], np.asarray(datin).astype(np.float32))

            # Run inference
            interpreter.invoke()

            # Get the output tensor
            test_predictions = interpreter.get_tensor(output_details[0]['index'])
            #-----------------------------------VVVI----------------------------------------
            #pred_text = 'Predicted Salary is '+str(int(test_predictions[0]))+' USD'
            pred_text = 'Predicted Salary is '+str(int(test_predictions[0][0]))+' USD'
            #------------------------------------------------------------------------------
            pred_style = {"border": "1px solid gray","border-radius": "5px","font-family": "Comfortaa", "font-size" :"13px",
                           "text-align":"center","display": "block"}
            return [ pred_text, pred_style]
        elif trigger_id == "analytics-output.children" and analytics_output == "Input Activated":
            pred_style = {"border": "1px solid gray","border-radius": "5px","font-family": "Comfortaa", "font-size" :"13px",
                           "text-align":"center","display": "none"}
            return [ "", pred_style]
        
        raise PreventUpdate
    #--------------------------------------------------------------------------------------------------------


    #-------------------------------------------------------------------------------------------
    @dash_app.callback(
        [Output('job title (by country)-input', 'options'), Output('job title (by country)-input', 'value')],
        Input('country-input', 'value'),
    )
    def update_job_type_options(selected_country):
        # Filter the DataFrame based on the selected "COUNTRY CODE"
        #print(selected_country,flush=True)
        filtered_df = df[df['COUNTRY'] == selected_country]
        
        # Get the unique values of the "JOB TYPE" column for the filtered DataFrame
        job_type_options = [{'label': value.title(), 'value': value} for value in filtered_df['JOB TITLE (BY COUNTRY)'].unique()]
        exception_dict={'Business Intelligence Engineer':'BI Engineer','Developer Qa Or Test':'qa Test Developer',
                        'Cloud Infrastructure Engineer':'Cloud Engineer', 'Game Or Graphics Developer':'Game Developer',
                        'Machine Learning Engineer':'ML Engineer', 'Data Science Or Ml Specialist':'AI/ML/DS Specialist'}
        #print(options, flush=True)
        for option in job_type_options:
            label = option['label']
            if label in exception_dict:
                option['label'] = exception_dict[label]
        # Reset the "JOB TYPE" dropdown value to None/First one
        job_type_value = job_type_options[0]['value']
        
        return job_type_options, job_type_value
    
    @dash_app.callback(
        [Output("reset-button", "disabled"),
         Output("get-analytics-button", "disabled"),
         ],
        Input("country-input", "value"),
        Input("job title (by country)-input", "value"),
        Input("company size-input", "value"),
        Input("education (degree)-input", "value"),
        Input("age (years)-input", "value"),
        Input("analytics-output", "children"),
    )
    def update_button_disabled(*value):
        # Check if any of the input fields are None
        input_vals = value[:5]
        flow_val = value[5]
        is_null_input = np.any(np.equal(input_vals, None))

        if(is_null_input):
            return [True,True]
        elif((not is_null_input) and (flow_val=="Input Activated")):
            return [True,False]
        elif((not is_null_input) and (flow_val=="Input Deactivated")):
            return [False,True]
        return [True,True]

    @dash_app.callback(
        [Output("analytics-output", "children"),
         Output("country-input", "disabled"),
         Output("job title (by country)-input", "disabled"),
         Output("age (years)-input", "disabled"),
         Output("company size-input", "disabled"),
         Output("education (degree)-input", "disabled"),
         Output("work-exp-input", "disabled"),
         Output("get-analytics-button", "n_clicks"),
         Output("reset-button", "n_clicks"),
         ],
        Input("get-analytics-button", "n_clicks"),
        Input("reset-button", "n_clicks"),
        prevent_initial_call=True,
    )
    def update_input_disabled(result_but, reset_but):
        if result_but and (reset_but is None or result_but > reset_but):
            state = "Input Deactivated"
            return [state,True,True,True,True,True,True,3,6]
        elif reset_but and (result_but is None or reset_but > result_but):
            state = "Input Activated"
            return [state,False,False,False,False,False,False,6,3]
    #---------------------------------------------------------------------
        
    @dash_app.callback(
        [Output('value-selector', 'options'),
        Output('value-selector', 'value')],
        Input('filter-selector', 'value')
    )
    def update_value_selector(selected_filter):
        options = [{'label': val.title(), 'value': val} for val in data[selected_filter].unique()]
        return options, options[0]['value']

    @dash_app.callback(
        Output('median-salary-plot', 'figure'),
        Input('filter-selector', 'value'),
        Input("country-input", "value"),
        Input("job title (by country)-input", "value"),
    )
    def update_median_salary_plot(selected_value, country_val, job_val):
        filtered_df = data[(data['COUNTRY'] == country_val) & (data['JOB TITLE (BY COUNTRY)'] == job_val)]
        median_salary = filtered_df.groupby(selected_value)['SALARY (USD)'].median().reset_index()
        
        fig = px.bar(median_salary, x=selected_value, y='SALARY (USD)', title=f'Median Salary by {selected_value.title()}')
        # Customize the layout
        fig.update_layout(
            #title_font=dict(size=10),  # Set title font size
            yaxis_title='Salary (USD)',  # Set x-axis title
            xaxis_title=selected_value.title(),  # Set y-axis title
            #font=dict(size=10),  # Set font size for axis labels and ticks
            #margin=dict(l=50, r=50, b=50, t=80),  # Adjust margin for better spacing
            #plot_bgcolor='lightgray',  # Set plot background color
            #paper_bgcolor='lightgray',  # Set paper background color
        )

        # Customize the histogram bars
        fig.update_traces(
            hovertemplate='',
            hoverinfo='none',
            marker=dict(line=dict(width=1, color='white')),  # Set bar color and border
            opacity=0.7,  # Set bar opacity
        )
        return fig

    @dash_app.callback(
        Output('salary-distribution-histogram', 'figure'),
        Input('filter-selector', 'value'),
        Input('value-selector', 'value'),
        Input("country-input", "value"),
        Input("job title (by country)-input", "value"),
    )
    def update_salary_distribution_plot(filtered_value, selected_value, country_val, job_val):
        filtered_df = data[(data['COUNTRY'] == country_val) & (data['JOB TITLE (BY COUNTRY)'] == job_val)]
        selected_df = filtered_df[filtered_df[filtered_value] == selected_value]
        
        fig = px.histogram(selected_df, x='SALARY (USD)', title=f' {filtered_value.title()}: {selected_value.title()}')
        # Customize the layout
        fig.update_layout(
            #title_font=dict(size=10),  # Set title font size
            xaxis_title='Salary (USD)',  # Set x-axis title
            yaxis_title='Data Point Count',  # Set y-axis title
            #font=dict(size=10),  # Set font size for axis labels and ticks
            #margin=dict(l=50, r=50, b=50, t=80),  # Adjust margin for better spacing
            #plot_bgcolor='lightgray',  # Set plot background color
            #paper_bgcolor='lightgray',  # Set paper background color
        )

        # Customize the histogram bars
        fig.update_traces(
            hovertemplate='',
            hoverinfo='none',
            marker=dict(line=dict(width=1, color='white')),  # Set bar color and border
            opacity=0.7,  # Set bar opacity
        )

        return fig

    @dash_app.callback(
            Output("analysis-header", "children"),
            Input("country-input", "value"),
            Input("job title (by country)-input", "value"),
    )
    def update_header(country_val, job_val):
        exception_dict={'Business Intelligence Engineer':'BI Engineer','Developer Qa Or Test':'qa Test Developer',
                        'Cloud Infrastructure Engineer':'Cloud Engineer', 'Game Or Graphics Developer':'Game Developer',
                        'Machine Learning Engineer':'ML Engineer', 'Data Science Or Ml Specialist':'AI/ML/DS Specialist'}
        jt = job_val.title()
        if jt in exception_dict:
            jt = exception_dict[jt]
        title_head = "Analyze Salary for "+str(jt)+"s in "+str(country_val.title())
        return title_head

    return dash_app
